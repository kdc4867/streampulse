--
-- PostgreSQL database dump
--

\restrict 4K18GmRvnJeeMdqm5iaEYSg6tWUvAVNq4RE7RazoJh8TUabb4VCXf6zfJDOzENe

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX public.idx_cool;
ALTER TABLE ONLY public.signal_events DROP CONSTRAINT signal_events_pkey;
ALTER TABLE public.signal_events ALTER COLUMN event_id DROP DEFAULT;
DROP SEQUENCE public.signal_events_event_id_seq;
DROP TABLE public.signal_events;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: signal_events; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.signal_events (
    event_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    platform character varying(20),
    category_name character varying(100),
    event_type character varying(50),
    growth_rate double precision,
    cause_detail jsonb
);


ALTER TABLE public.signal_events OWNER TO "user";

--
-- Name: signal_events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.signal_events_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.signal_events_event_id_seq OWNER TO "user";

--
-- Name: signal_events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.signal_events_event_id_seq OWNED BY public.signal_events.event_id;


--
-- Name: signal_events event_id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.signal_events ALTER COLUMN event_id SET DEFAULT nextval('public.signal_events_event_id_seq'::regclass);


--
-- Data for Name: signal_events; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.signal_events (event_id, created_at, platform, category_name, event_type, growth_rate, cause_detail) FROM stdin;
13	2025-12-28 20:51:51.002515	CHZZK	콜 오브 듀티: 블랙 옵스 7	PERSON_ISSUE	775.25	{"clues": [{"id": "4de764d9dad3b25602284be6db3ac647", "name": "아리사", "title": "Xbox Game Pass X-MAS Relay\\n", "viewers": 2572}, {"id": "8803cee946a9e610a76fbdee98d98c61", "name": "룩삼", "title": "룩삼 Xbox Game Pass X-MAS Relay", "viewers": 1408}, {"id": "5b34555b2eb7a525aa3b36a7cfff93e9", "name": "이게뭔곰", "title": "두배 아직 안끝났쥬? / 팔로우 100명 감사합니다", "viewers": 6}], "stats": {"delta": 3981, "current": 3987, "baseline_season": 5}}
14	2025-12-28 21:11:53.315217	SOOP	마인크래프트	STRUCTURE_ISSUE	50.04	{"clues": [{"id": "rrvv17", "name": "항상#킴성태", "title": "킴성태 저는조롱당했습니다", "viewers": 16056}, {"id": "jdm1197", "name": "악어∀", "title": "마크에이지 리턴즈 3 : 잊혀진 전설 5회차 &lt;개리 멸망&gt;", "viewers": 13931}, {"id": "mystery58", "name": "냥언니", "title": "[구름서버] 잠이 안깬다아~ 나두 200개 선물주라냥ㅠㅠ /다야 노방종룰렛200개 #API연동#마크#배그#메랜", "viewers": 48}], "stats": {"delta": 30025, "current": 30638, "baseline_season": 612}}
15	2025-12-28 21:16:54.085845	CHZZK	데드 바이 데이라이트	PERSON_ISSUE	12.14	{"clues": [{"id": "7ce8032370ac5121dcabce7bad375ced", "name": "풍월량", "title": "4명이서 한명 눈 멀게하는 게임 ", "viewers": 10817}, {"id": "792b7d3e64c159a6d31ff67eee018f17", "name": "묵병철", "title": "헐안녕", "viewers": 252}, {"id": "792b7d3e64c159a6d31ff67eee018f17", "name": "묵병철", "title": "헐안녕", "viewers": 246}], "stats": {"delta": 10935, "current": 11917, "baseline_season": 981}}
16	2025-12-28 21:36:56.102439	CHZZK	다키스트 던전	PERSON_ISSUE	50.35	{"clues": [{"id": "7efa5b40ee1729ac57d3adbebf3ddb3c", "name": "살구", "title": "다키스트 던전 혈월 엔딩보기", "viewers": 820}, {"id": "7efa5b40ee1729ac57d3adbebf3ddb3c", "name": "살구", "title": "다키스트 던전 혈월 엔딩보기", "viewers": 812}, {"id": "942b386236dc95a9398477121f40de1d", "name": "한오크", "title": "영지 터졋다!2영지", "viewers": 2}], "stats": {"delta": 1601, "current": 1634, "baseline_season": 32}}
17	2025-12-28 21:41:57.064666	SOOP	음악 라이브	PERSON_ISSUE	7.42	{"clues": [{"id": "thwl9386", "name": "지붕위소희", "title": "뭔가 굉장히 오랜만...", "viewers": 2034}, {"id": "gkstkd14", "name": "댄동단장태우", "title": "EP.4 DD GIRLS2 엔딩요정 결정전!!", "viewers": 795}, {"id": "hwt1014", "name": "가습기", "title": "습레기통 24시간 퇴근전쟁... #감컴퍼니", "viewers": 476}], "stats": {"delta": 4049, "current": 4680, "baseline_season": 630}}
18	2025-12-28 21:56:58.677465	CHZZK	블루 아카이브	PERSON_ISSUE	6.43	{"clues": [{"id": "2708947b66f527fd74e6b3d6bcc1349b", "name": "러끼", "title": "'고막여친'들과 블루아카이브 이벤스 더빙 합방 🩷", "viewers": 1077}, {"id": "f2fd35b4bce38e375cd77b6a6904b4a4", "name": "부쿠키", "title": "고막여친만 모였습니다 ✨ w. 러끼 설백", "viewers": 679}, {"id": "a048127622edd6c3ee8e477471a1d823", "name": "빙하유", "title": "블루아카이브 에덴 2~3장 더빙 몰아보기 (안본눈)", "viewers": 672}], "stats": {"delta": 2566, "current": 3039, "baseline_season": 472}}
19	2025-12-28 21:56:58.688271	CHZZK	마이 썸머 카	PERSON_ISSUE	181.38	{"clues": [{"id": "bc2dbff369307b5c446224cce192c8b1", "name": "과로사1", "title": "주유소 개패기 하드코어 모드 4회차", "viewers": 633}, {"id": "bc2dbff369307b5c446224cce192c8b1", "name": "과로사1", "title": "주유소 개패기 하드코어 모드 4회차", "viewers": 619}, {"id": "f7e62a41cfff5b33e29245e52f8431b5", "name": "Roughwow 러프와우", "title": "(버미육) 내 일요일 어디갔어 카자흐스키", "viewers": 7}], "stats": {"delta": 1252, "current": 1259, "baseline_season": 6}}
20	2025-12-28 22:01:59.726764	CHZZK	전략적 팀 전투: 신화와 전설	PERSON_ISSUE	1.59	{"clues": [{"id": "0dad8baf12a436f722faa8e5001c5011", "name": "따효니", "title": "기다리면서 롤체 듀오 근판", "viewers": 4636}, {"id": "b40ce4b4204a494a97c55c251e092424", "name": "두니주니", "title": "시즌 부적응자.. 하지만 오늘은", "viewers": 1766}, {"id": "21a0de8b586c517181d76f183272de57", "name": "헤징", "title": "롤체 개못해 오명(?) 벗기....", "viewers": 403}], "stats": {"delta": 2706, "current": 7318, "baseline_season": 4611}}
21	2025-12-28 22:01:59.741532	CHZZK	음악/노래	STRUCTURE_ISSUE	1.83	{"clues": [{"id": "798e100206987b59805cfb75f927e965", "name": "디디디용", "title": "8시) 포포랑 돈스크림 투게더 후열 노래방송", "viewers": 792}, {"id": "5c897b3e639045ca6e314bbaff991f73", "name": "비올레타 모네", "title": "안넝ㅇ", "viewers": 371}, {"id": "4f650f02bc4ab38a998d74e3abb1b68b", "name": "유레이 UREI", "title": "으아아ㅏㅏ아ㅏ.", "viewers": 176}], "stats": {"delta": 1090, "current": 2396, "baseline_season": 1305}}
22	2025-12-28 22:12:01.764393	SOOP	PUBG: 배틀그라운드	PERSON_ISSUE	2.87	{"clues": [{"id": "rrvv17", "name": "항상#킴성태", "title": "킴성태 배그멸망전 경매전 회의", "viewers": 19746}, {"id": "pubg", "name": "PUBG공식", "title": "PUBG ASIA CLAN CUP 한국 대표 선발전 | 스팀", "viewers": 1104}, {"id": "gudcjf604", "name": "블랙워크", "title": "블랙워크 리아 칠득 설이vs아칸 먼지 걸뽀 땡지 지옥의킬내기 ㅎㅎ 배틀그라운드", "viewers": 1038}], "stats": {"delta": 20781, "current": 31896, "baseline_season": 11114}}
23	2025-12-28 22:12:01.776171	SOOP	리그 오브 레전드	PERSON_ISSUE	3.84	{"clues": [{"id": "khm11903", "name": "봉준", "title": "봉준 vs정윤종 박습니다 롤 CK LOL", "viewers": 35426}, {"id": "pig2704", "name": "프으레이", "title": "증바람 출발", "viewers": 5896}, {"id": "joey1114", "name": "저라뎃", "title": "연말결산", "viewers": 5269}], "stats": {"delta": 47286, "current": 63957, "baseline_season": 16670}}
24	2025-12-28 22:22:03.2918	CHZZK	마운트 앤 블레이드 2: 배너로드	PERSON_ISSUE	1.66	{"clues": [{"id": "0a0a0b83c6af289507ef57a5f3d623c0", "name": "멀럭킹", "title": "배너로드2 - 다시 태어남;;;", "viewers": 1320}, {"id": "0a0a0b83c6af289507ef57a5f3d623c0", "name": "멀럭킹", "title": "배너로드2 - 다시 태어남;;;", "viewers": 1307}, {"id": "6aef261524faf48ca3f5b463ba29f061", "name": "금쿤", "title": "천통은 시간문제인데 나이가 환갑이 넘음", "viewers": 349}], "stats": {"delta": 1269, "current": 3202, "baseline_season": 1932}}
25	2025-12-28 22:42:05.661283	CHZZK	방 탈출 시뮬레이터2	PERSON_ISSUE	3.67	{"clues": [{"id": "0dad8baf12a436f722faa8e5001c5011", "name": "따효니", "title": "따던룩 91시치들의 방탈출", "viewers": 5356}, {"id": "8803cee946a9e610a76fbdee98d98c61", "name": "룩삼", "title": "룩삼 따효니 던 방탈출 시뮬레이터2", "viewers": 2255}, {"id": "dc740d5bb5680666b6bf2ebc58a8203f", "name": "던", "title": "91 방탈출", "viewers": 127}], "stats": {"delta": 5875, "current": 8075, "baseline_season": 2199}}
26	2025-12-28 23:17:09.803133	CHZZK	돈트 스크림 투게더	PERSON_ISSUE	86.65	{"clues": [{"id": "912b559dcdd9c9ea1fe97864925738bf", "name": "왈도쿤", "title": "[왈도쿤] 절대 \\"비명\\"을 질러서는 안돼! (w 아구이뽀, 이로나묭 치카, 푸린)", "viewers": 1862}, {"id": "ec30975bd41d3179fe7734ddbf760acb", "name": "이로나묭 치카", "title": "찍찍...찍찍찍... w.아구이뽀님 푸린님 왈도쿤님", "viewers": 674}], "stats": {"delta": 2506, "current": 2536, "baseline_season": 29}}
27	2025-12-28 23:27:10.988122	CHZZK	리그 오브 레전드	PERSON_ISSUE	1.46	{"clues": [{"id": "4d812b586ff63f8a2946e64fa860bbf5", "name": "하나코 나나", "title": "증바람 쨰애애끔", "viewers": 3569}, {"id": "0947e9a9cbc8a2bfdc61b83ccbd2b490", "name": "찬우정", "title": "C1 1183 < GM 910 .정글함", "viewers": 261}, {"id": "0947e9a9cbc8a2bfdc61b83ccbd2b490", "name": "찬우정", "title": "C1 1183 < GM 910 .정글함", "viewers": 245}], "stats": {"delta": 2109, "current": 6649, "baseline_season": 4539}}
28	2025-12-28 23:27:11.019786	CHZZK	종합 게임	PERSON_ISSUE	1.8	{"clues": [{"id": "1ad5aa0f6c6741b072528fad5e5e76b1", "name": "윤가놈", "title": "포켓몬 신작 올라라 포켓몬타워", "viewers": 9794}, {"id": "7b1acb37b35928ff690d011296a9e5ab", "name": "케인", "title": "[케인] ai 대화 게임 (주인공 : 케인)", "viewers": 1376}, {"id": "6fccf2c08f2e9f801fc3152a8923e1c2", "name": "눈파티입니다", "title": "연말맞이 어나더레드 제작자님의 새로운 신작 올라라 포켓몬 타워", "viewers": 974}], "stats": {"delta": 6417, "current": 14476, "baseline_season": 8058}}
29	2025-12-29 00:17:16.394942	CHZZK	리듬 닥터	PERSON_ISSUE	4.61	{"clues": [{"id": "4de764d9dad3b25602284be6db3ac647", "name": "아리사", "title": "리듬의 황", "viewers": 3268}, {"id": "88a3cc93da8b998e0958811fcd509b77", "name": "베비야 Bebiya", "title": "레?디? 겟?서?큐?버?스?💙🐰강림 47일차", "viewers": 3}], "stats": {"delta": 2561, "current": 3271, "baseline_season": 709}}
30	2025-12-29 00:37:19.596134	CHZZK	엘든 링	PERSON_ISSUE	40.91	{"clues": [{"id": "a3ceb9179d99be8d1e63b3e911fcd16b", "name": "키유 Kiyuu", "title": "뉴비 비털털이로 트리가드 잡다!!!", "viewers": 558}, {"id": "a3ceb9179d99be8d1e63b3e911fcd16b", "name": "키유 Kiyuu", "title": "뉴비 비털털이로 트리가드 잡다!!!", "viewers": 552}, {"id": "46440ed33bb20975061859d3d63f299f", "name": "은슨", "title": "밀키트님 제발 살려주세요", "viewers": 8}], "stats": {"delta": 1100, "current": 1128, "baseline_season": 27}}
31	2025-12-29 00:57:21.158007	CHZZK	마법소녀의 마녀재판	PERSON_ISSUE	12.39	{"clues": [{"id": "feb20a676694b1163fed010da0848303", "name": "샘웨", "title": "마법소녀의 마녀재판 2-4", "viewers": 1532}, {"id": "feb20a676694b1163fed010da0848303", "name": "샘웨", "title": "마법소녀의 마녀재판 2-4", "viewers": 1523}, {"id": "4f650f02bc4ab38a998d74e3abb1b68b", "name": "유레이 UREI", "title": "아닛 !! 레이 방에서 차갑게 식은 피자 발견 !?! (호호) 다들 라운지로 모여주세요 (호호)", "viewers": 191}], "stats": {"delta": 3053, "current": 3321, "baseline_season": 267}}
32	2025-12-29 01:17:22.988639	CHZZK	발더스 게이트 3	PERSON_ISSUE	4.59	{"clues": [{"id": "dc7fb0d085cfbbe90e11836e3b85b784", "name": "강소연", "title": "발더게3 뉴비팟 강풍듀오 (불명예)난이도 2주차 글씨 읽으라고 하면 시위간다 흐흐흫ㅎ", "viewers": 2102}, {"id": "089185efc29a8fbe14ea294dc85f9661", "name": "소풍왔니", "title": "강풍 발더스 게이트 끝이 다가오...나? / 팝업 마지막날", "viewers": 1481}, {"id": "089185efc29a8fbe14ea294dc85f9661", "name": "소풍왔니", "title": "강풍 발더스 게이트 끝이 다가오...나? / 팝업 마지막날", "viewers": 1468}], "stats": {"delta": 3982, "current": 5091, "baseline_season": 1108}}
33	2025-12-29 01:17:23.003721	CHZZK	이스케이프 프롬 타르코프	PERSON_ISSUE	5.01	{"clues": [{"id": "7ce8032370ac5121dcabce7bad375ced", "name": "풍월량", "title": "총쏘면 상대방템 다 가지는 게임 ", "viewers": 12188}, {"id": "bf4df7913fcc6c4bd0932a37310a761f", "name": "씨랙", "title": "일요일 타르코프 씨랙", "viewers": 1124}, {"id": "fc00d47a77ed2d1156cd5997eba30310", "name": "소우릎", "title": "카파가자", "viewers": 1052}], "stats": {"delta": 12433, "current": 15533, "baseline_season": 3099}}
34	2025-12-29 02:22:29.846992	CHZZK	마운트 앤 블레이드 2: 배너로드	PERSON_ISSUE	2.63	{"clues": [{"id": "0a0a0b83c6af289507ef57a5f3d623c0", "name": "멀럭킹", "title": "배너로드2 - 다시 태어남;;;", "viewers": 1061}, {"id": "0a0a0b83c6af289507ef57a5f3d623c0", "name": "멀럭킹", "title": "배너로드2 - 다시 태어남;;;", "viewers": 1060}, {"id": "6aef261524faf48ca3f5b463ba29f061", "name": "금쿤", "title": "천통은 시간문제인데 나이가 환갑이 넘음", "viewers": 312}], "stats": {"delta": 1701, "current": 2747, "baseline_season": 1045}}
35	2025-12-29 03:42:36.493355	CHZZK		PERSON_ISSUE	4.25	{"clues": [{"id": "29f20622463916fa48ad735057b145ce", "name": "멋사", "title": "스읍", "viewers": 1768}, {"id": "c1c5bd0bf580d7996230d08d0a6667b1", "name": "메ry", "title": "그림", "viewers": 117}, {"id": "6e9cd057096534b211e6fc6322acc5c6", "name": "로독", "title": "12월 28일\\n1. 풋챔 5경기\\n2. EPL 선더랜드 리즈\\n3. EPL 크리스탈 팰리스 토트넘", "viewers": 23}], "stats": {"delta": 1630, "current": 2132, "baseline_season": 501}}
36	2025-12-29 04:12:41.522341	CHZZK		PERSON_ISSUE	5.5	{"clues": [{"id": "29f20622463916fa48ad735057b145ce", "name": "멋사", "title": "스읍", "viewers": 2523}, {"id": "c1c5bd0bf580d7996230d08d0a6667b1", "name": "메ry", "title": "그림", "viewers": 114}, {"id": "e0fec2f10bb8c07a79573cdba8c152b5", "name": "병병병2", "title": "병병병 자는중", "viewers": 29}], "stats": {"delta": 2319, "current": 2835, "baseline_season": 515}}
\.


--
-- Name: signal_events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.signal_events_event_id_seq', 36, true);


--
-- Name: signal_events signal_events_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.signal_events
    ADD CONSTRAINT signal_events_pkey PRIMARY KEY (event_id);


--
-- Name: idx_cool; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_cool ON public.signal_events USING btree (platform, category_name, created_at);


--
-- PostgreSQL database dump complete
--

\unrestrict 4K18GmRvnJeeMdqm5iaEYSg6tWUvAVNq4RE7RazoJh8TUabb4VCXf6zfJDOzENe

